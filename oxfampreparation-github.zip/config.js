// Paste your Supabase project URL and anon public key here. Leave empty for demo mode.
window.SB={url:"",key:""};
