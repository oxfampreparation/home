# Oxfam Preparation

Statický web. Nahrajte celý obsah této složky do GitHub repozitáře a zachovejte strukturu složek:

```
index.html            úvodní stránka
config.js             nastavení přihlášení (Supabase)
supabase-setup.sql    SQL pro Supabase
CNAME                 doména oxfampreparation.online
fce/index.html        stránka zkoušky FCE
fce/2026/index.html   test FCE 2026
cae/index.html        stránka zkoušky CAE
cae/2026/index.html   test CAE 2026
... stejně pro ket, pet, pet-schools, fce-schools, cpe, ielts a roky 2020 až 2026
```

Adresy na webu pak vypadají takto: /cae/ a /cae/2026/. Každý test je ve své složce a jeho obsah doplníte v souboru index.html v dané složce (komentář ADD ... HERE).

Při nahrávání na github.com přetáhněte celé složky najednou do okna Upload files. Pokud by prohlížeč odmítl moc souborů, nahrajte nejdřív soubory v kořeni a potom po jedné složce zkoušky (například fce).

## Přihlášení (Supabase, zdarma)

Bez nastavení běží přihlášení v ukázkovém režimu: přijme jakýkoli e-mail a heslo a nic nechrání.

1. Na supabase.com vytvořte projekt.
2. Otevřete SQL Editor, vložte obsah souboru supabase-setup.sql a spusťte ho.
3. Authentication, Providers, Email: vypněte možnost registrace nových uživatelů. Uživatele pak vytváříte vy v Authentication, Users, Add user.
4. Settings, API: zkopírujte Project URL a anon public key do souboru config.js. Anon klíč je určen k tomu, aby byl veřejný, o ochranu se stará tabulka s pravidly přístupu.
5. Obsah testů vkládejte do tabulky test_parts v Table Editoru. Sloupec key má tvar fce-2026-part1 (první část testu FCE 2026), klíč odpovědí má tvar fce-2026-part1-answers. Sloupec html je obsah testu.

Obsah z tabulky vydá server jen přihlášenému uživateli. Cokoli, co napíšete přímo do HTML souborů na GitHubu, je veřejné.
