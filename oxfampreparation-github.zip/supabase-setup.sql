create table if not exists test_parts (key text primary key, html text not null);
alter table test_parts enable row level security;
create policy "logged in users can read tests" on test_parts for select to authenticated using (true);
